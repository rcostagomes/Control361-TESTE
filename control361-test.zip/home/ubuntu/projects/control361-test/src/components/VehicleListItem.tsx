import React from 'react';
import { Vehicle } from '@/types/vehicle';

interface VehicleListItemProps {
  vehicle: Vehicle;
  onVehicleSelect: (vehicle: Vehicle) => void; // Callback to open modal
}

const VehicleListItem: React.FC<VehicleListItemProps> = ({ vehicle, onVehicleSelect }) => {
  return (
    <tr 
      className="border-b border-gray-700 hover:bg-gray-700/50 cursor-pointer"
      onClick={() => onVehicleSelect(vehicle)} // Open modal on click
    >
      <td className="px-4 py-3 whitespace-nowrap">{vehicle.placa}</td>
      <td className="px-4 py-3 whitespace-nowrap">{vehicle.frota}</td>
      <td className="px-4 py-3 whitespace-nowrap">{vehicle.tipo}</td>
      <td className="px-4 py-3 whitespace-nowrap">{vehicle.modelo}</td>
      <td className="px-4 py-3 whitespace-nowrap">{vehicle.status}</td>
    </tr>
  );
};

export default VehicleListItem;

