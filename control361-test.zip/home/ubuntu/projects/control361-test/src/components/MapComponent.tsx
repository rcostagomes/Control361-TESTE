import { GoogleMap, LoadScript, Marker } from '@react-google-maps/api';
import React from 'react';
import { Vehicle } from '@/types/vehicle'; // Assuming Vehicle type includes lat/lng

const containerStyle = {
  width: '100%',
  height: '300px', // Adjusted height for better layout
};

// Default center (São Paulo, Brazil)
const defaultCenter = {
  lat: -23.55052,
  lng: -46.633308,
};

interface MapComponentProps {
  apiKey: string;
  vehicles: Vehicle[]; 
}

const MapComponent: React.FC<MapComponentProps> = ({ apiKey, vehicles }) => {
  if (!apiKey) {
    return <div className="h-[300px] w-full flex items-center justify-center bg-gray-700 text-gray-400">Chave da API do Google Maps não configurada.</div>;
  }

  return (
    <LoadScript googleMapsApiKey={apiKey} loadingElement={<div className="h-[300px] w-full flex items-center justify-center bg-gray-700 text-gray-400">Carregando Mapa...</div>}>
      <GoogleMap
        mapContainerStyle={containerStyle}
        center={defaultCenter}
        zoom={10} // Initial zoom level
      >
        {vehicles && vehicles.map((vehicle) => {
          if (vehicle.ultimaPosicao && typeof vehicle.ultimaPosicao.lat === 'number' && typeof vehicle.ultimaPosicao.lng === 'number') {
            return (
              <Marker
                key={vehicle.id || vehicle.placa}
                position={{ lat: vehicle.ultimaPosicao.lat, lng: vehicle.ultimaPosicao.lng }}
                title={`Placa: ${vehicle.placa}\nFrota: ${vehicle.frota}`}
                // TODO: Add custom icon based on vehicle.cor or type (Task 5.5 extension)
                // TODO: Add onClick handler to show vehicle details (Task 5.7 / Task 7)
              />
            );
          }
          return null;
        })}
      </GoogleMap>
    </LoadScript>
  );
};

export default MapComponent;

