import { useInfiniteQuery } from '@tanstack/react-query';
import axios from 'axios';
import { Vehicle, FetchVehiclesParams, PaginatedVehiclesResponse } from '@/types/vehicle';

const API_BASE_URL = 'https://develop-back.rota361.com.br/recruitment';

// Fetch function for useInfiniteQuery
const fetchVehicles = async ({
  pageParam = 1,
  queryKey,
}: {
  pageParam?: number;
  queryKey: [string, Omit<FetchVehiclesParams, 'page' | 'perPage'> & { perPage: number }];
}): Promise<PaginatedVehiclesResponse> => {
  const [_key, params] = queryKey;
  const { type, perPage, filter } = params;

  const queryParams = new URLSearchParams();
  queryParams.append('type', type);
  queryParams.append('page', pageParam.toString());
  queryParams.append('perPage', perPage.toString());

  if (filter) {
    queryParams.append('filter', filter);
  }

  const response = await axios.get<PaginatedVehiclesResponse>(
    `${API_BASE_URL}/vehicles/list-with-paginate?${queryParams.toString()}`
  );
  // The API directly returns the PaginatedVehiclesResponse structure
  // { "data": Vehicle[], "total": number, "pagina": number, "porPagina": number, "totalPaginas": number }
  return response.data;
};

// Hook personalizado para buscar veículos com rolagem infinita
export const useInfiniteVehicles = (params: Omit<FetchVehiclesParams, 'page'>) => {
  return useInfiniteQuery<PaginatedVehiclesResponse, Error>(
    ['vehicles', params], // Chave da query, inclui params para refetch quando mudar
    fetchVehicles,
    {
      getNextPageParam: (lastPage) => {
        // lastPage é PaginatedVehiclesResponse
        const nextPage = lastPage.pagina + 1;
        return nextPage <= lastPage.totalPaginas ? nextPage : undefined;
      },
      keepPreviousData: true, // Mantém os dados anteriores enquanto busca novos
      // Outras opções do React Query podem ser configuradas aqui
    }
  );
};

