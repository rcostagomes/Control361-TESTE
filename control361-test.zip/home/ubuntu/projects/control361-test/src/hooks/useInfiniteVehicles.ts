import { useInfiniteQuery } from '@tanstack/react-query';
import axios from 'axios';

const API_BASE_URL = 'https://develop-back.rota361.com/recruitment';

interface Vehicle {
  id: string;
  placa: string;
  frota: string;
  tipo: string;
  modelo: string;
  status: string;
  latitude: number;
  longitude: number;
}

interface PaginatedVehiclesResponse {
  data: Vehicle[];
  total: number;
  pagina: number;
  porPagina: number;
  totalPaginas: number;
}

const fetchVehicles = async ({ pageParam = 1, queryKey }: any) => {
  const [_key, params] = queryKey;
  const { type, filter } = params;

  const queryParams = new URLSearchParams();
  queryParams.append('page', pageParam.toString());
  queryParams.append('perPage', '20'); // Assuming 20 items per page as per requirement

  if (type) {
    queryParams.append('type', type);
  }
  if (filter) {
    queryParams.append('filter', filter);
  }

  const response = await axios.get<PaginatedVehiclesResponse>(
    `${API_BASE_URL}/vehicles/list-with-paginate?${queryParams.toString()}`
  );
  return response.data;
};

export const useInfiniteVehicles = (params: { type: string; filter?: string }) => {
  return useInfiniteQuery<PaginatedVehiclesResponse, Error>(
    ['vehicles', params], // Query key includes params to refetch when they change
    ({ pageParam = 1 }) => fetchVehicles({ pageParam, ...params }),
    {
      getNextPageParam: (lastPage) => {
        // Assuming 'lastPage' has a 'pagina' (current page) and 'totalPaginas' (total pages)
        if (lastPage.pagina < lastPage.totalPaginas) {
          return lastPage.pagina + 1;
        }
        return undefined; // No more pages
      },
    }
  );
};

