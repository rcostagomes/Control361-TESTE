export interface Vehicle {
  id: string | number;
  placa: string;
  frota: string;
  tipo: string; // Ex: "Motor", "Carreta"
  modelo: string;
  status: string; // Ex: "Em viagem", "Disponível"
  cor?: string; // Adicionado para o ícone do mapa, pode ser criativo
  nomeMotorista?: string; // Ex: "Mario Mamede" para o popup do mapa
  ultimaPosicao?: {
    lat: number;
    lng: number;
    dataHora?: string;
  };
}

export interface PaginatedVehiclesResponse {
  data: Vehicle[];
  total: number; // Total de itens
  pagina: number; // Página atual
  porPagina: number; // Itens por página
  totalPaginas: number; // Total de páginas
  // A API real pode ter uma estrutura diferente para metadados de paginação
  // Exemplo de uma estrutura comum:
  // meta?: {
  //   currentPage: number;
  //   perPage: number;
  //   totalPages: number;
  //   totalItems: number;
  // };
}

// Parâmetros para a API list-with-paginate
export interface FetchVehiclesParams {
  type: string; // 'rastreados' ou 'outros' (conforme UI, mas API só retorna rastreados)
  page: number;
  perPage: number;
  filter?: string; // placa ou frota
}

