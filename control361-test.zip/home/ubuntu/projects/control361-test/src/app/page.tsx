"use client";

import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import VehicleList from '@/components/VehicleList';

// Create a client
const queryClient = new QueryClient();

export default function HomePage() {
  return (
    <QueryClientProvider client={queryClient}>
      <main className="min-h-screen bg-gray-900 text-white">
        {/* Adicionar o nome e sobrenome conforme a imagem */}
        <header className="p-4 bg-gray-800 shadow-md">
          <h1 className="text-xl font-semibold">Seu nome e sobrenome aqui</h1>
        </header>
        <VehicleList />
      </main>
    </QueryClientProvider>
  );
}

